/**
 * @mainpage course and student function demonstration
 * 
 * the course and student funtion demonstration shows how multiple functions in the couse and studentwork, including:
 * - printing course and student informations
 * - adding student to course and add grade to student
 * - determinging the top student and passing students
 * - randomly generating students
 * @file main.c
 * @author sunw53
 * @date 2022/04/06
 * @brief 
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * creates a course called MATH101 with its name and course code. then randomly generates 20
 student with 8 grades. then use the print_course function to print the course information.
 then finds out the topstudent in the class and print the student's information by print_student function.
 finally print out the total number of passing students and their information.
 * 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}