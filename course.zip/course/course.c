/**
 * @file course.c
 * @author sunw53
 * @date 2022/04/06
 * @brief courses, including enroll_student, print_course, top_student, passing functions.
 *
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/** 
 * this function enrolls student in a course. Allocate the total number of students in an array and add that student in to the array
 * 
 * @param course in Course type, and student in Student type
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
    // if total students is 1 then allocate an array of size 1.

  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
      // else reallocate the array of size total students.
 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Prints a course by its name, course code, and total student, and finally prints
 information of each student, including his/her first name, last name, student id, grade and average grade.
 * 
 * @param course in Course type
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/** 
 * if total students is 0, return null.
 else define a student_average and a max_average variable, for each student in the course,
 if this student has average higher than the max_average variable, his average becomes the new max_average.
 finally return the student that has the top average grade.
 * 
 * @param course in Course type.
 * @return student in Student type
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * this function counts the total number of students that passed the course,
 and allocate a dynamic array that stores all the students that passed the course.
 * 
 * @param course in Course type and total_passing pointer.
 * @return passing as an array that stores all the students that passed.
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
  // if the average of the student is larger than 50, then add 1 to count
   
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    
    }
    // if the average of the student is larger than 50, then add this student to the allocated array called passing
   
  }

  *total_passing = count;

  return passing;
}