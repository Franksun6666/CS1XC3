/**
 * @file course.h
 * @author sunw53
 * @date 2022/04/06
 * @brief a Course type defined, and enroll_student, print_course, top_student, passing function declarations.
 *
 */
#include "student.h"
#include <stdbool.h>

/**
* Course type stores a course name, code, students array, and total number of students.
*
*/ 

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


